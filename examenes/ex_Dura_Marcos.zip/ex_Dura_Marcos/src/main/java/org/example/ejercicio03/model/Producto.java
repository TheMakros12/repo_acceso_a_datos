package org.example.ejercicio03.model;

public class Producto {
}
